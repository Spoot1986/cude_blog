<?php
/*
 * Template part for displaying page content in page.php
 */
?>
<div class="cb_page">
	<div class="entry-content">
		<?php the_content();?>
	</div>
</div>