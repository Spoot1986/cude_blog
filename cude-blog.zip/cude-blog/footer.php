<?php
/*
 * The template for displaying the footer
 */
?>

	</div><!-- #content -->

	<footer>		
		<?php dynamic_sidebar( 'footer-1' ); ?>
	</footer>	

	<?php wp_footer(); ?>

	<div class="cude_blog_to_top"><i class="fa fa-chevron-circle-up" aria-hidden="true"></i></div>
	
</body>
</html>
