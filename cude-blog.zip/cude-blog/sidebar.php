<?php
/*
 * The sidebar containing the main widget area
 */
?>

<div class="secondary">
	<aside class="widget-area">
		<?php dynamic_sidebar( 'sidebar-1' ); ?>
	</aside>	
</div>